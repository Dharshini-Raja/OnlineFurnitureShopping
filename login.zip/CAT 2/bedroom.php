<html>
<head>
<title>  bedroom products </title>
<link rel="stylesheet" href="C:\Users\dhars\Desktop\WT Lab\Furnished Flow\styles.css" />
<script src="C:\Users\dhars\Desktop\WT Lab\Furnished Flow\Small Codes\store.js" async></script>
<style>
a:link {
  color: black;
  text-decoration: none;
}
a:visited {
  color: black;
  text-decoration: none;
}
a:active {
  color: gray;
  background-color: transparent;
  text-decoration: none;
}
</style>
</head>
<body>
<pre>
<a href="http://localhost/WT%20php/CAT%202/Main%20Page.php"> Go to Home Page</a>
<center>
<h1>Bedroom Products</h1>
<a name="top"></a>
<h1><b> BED </b></h1>
<img  src="https://blog.modsy.com/wp-content/uploads/2018/10/https-_www.modsy_.com_design-ideas_bedroom_modern_organic-modern-bedroom-with-leather-upholstered-bed_852111_3_elsie_userview_1.jpg" alt="bed" width="300" height="300" border="1px"><br/>
<a href="#product details1"> click to view product details</a><br/>

<h1><b> DRESSING TABLE </b></h1>
<img  src="https://ae01.alicdn.com/kf/H42e8489c222a48228730372d9f70c129B/Nordic-dressing-table-bedroom-small-apartment-modern-simple-luxury-corner-makeup-table-net-red-makeup-table.jpg_q50.jpg" alt="dressing table" width="300" height="300" border="1px"><br/>
<a href="#product details2"> click to view product details</a><br/>

<h1><b> SOFA CUM BED </b></h1>
<img  src="https://5.imimg.com/data5/HE/GV/MY-24288716/mac-01-500x500.jpg" alt="sofa cum bed" width="300" height="300" border="1px"><br/>
<a href="#product details3">click to view product details</a><br/>

<h1><b> PILLOW </b></h1>
<img  src="https://cdn.shopify.com/s/files/1/0012/6477/9327/products/minna-angle-pillow-terracotta-pillows-minna-844853_1090x.jpg?v=1573532252" alt="pillow" width="300" height="300" border="1px"><br/>
<a href="#product details4"> click to view product details</a><br/>

 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 
 <a name="product details1"></a><br/>	  
<img src="https://images-na.ssl-images-amazon.com/images/I/91F7qGRLAnL._AC_SX466_.jpg" alt="bed2" width="400" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://www.modway.com/globalassets/sites/bedroom/bed-frames/mod-6214-wal_7_.jpg" alt="bed3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://media.architecturaldigest.com/photos/5f04d29c4402fd6784839e41/master/pass/DondraQueenBedWeekendrJN19.jpeg" alt="bed4" width="300" height="300" border="1px"> 
 <h2>EBANSAL Queen Solid Wood Bed With Storage -(Honey Finish_Brown)   

 <a href="#top"> Go back to previous</a> <br/></h2>
 
 <a name="product details2"></a><br/>	  
<img src="https://ae01.alicdn.com/kf/H5e7d6aaf140a4fff9d4507bc1627f2875/Nordic-dressing-table-bedroom-small-apartment-modern-simple-luxury-corner-makeup-table-net-red-makeup-table.jpg_q50.jpg" alt="dressing table2"width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://ae01.alicdn.com/kf/H8c38af4bb0bc490c987ed4715e8bb8f2O/Nordic-dressing-table-bedroom-small-apartment-modern-simple-luxury-corner-makeup-table-net-red-makeup-table.jpg_q50.jpg" alt="dressing table3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://ae01.alicdn.com/kf/H6b8cb62601294272a0e4286bdc79d476P/Nordic-dressing-table-bedroom-small-apartment-modern-simple-luxury-corner-makeup-table-net-red-makeup-table.jpg_q50.jpg" alt="dressing table4" width="300" height="300" border="1px"> 
 <h2>Spacewood Value Dressing Table (Natural Wenge)

   <a href="#top"> Go back to previous</a><br/></h2>
 
 <a name="product details3"></a><br/>	  
<img src="https://5.imimg.com/data5/RN/IQ/MY-24288716/wooden-sofa-cum-bed-with-4-pillows-500x500.jpg" alt="sofa cum bed2"width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://5.imimg.com/data5/UB/GH/MY-24288716/wooden-sofa-cum-bed-with-4-pillows-500x500.jpg" alt="sofa cum bed3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://5.imimg.com/data5/HC/PF/MY-24288716/wooden-sofa-cum-bed-with-4-pillows-500x500.jpg" alt="sofa cum bed4" width="300" height="300" border="1px"> 
 <h2>Aart Store High-Density Foam Sofa Cum Bed Furniture Two Seater (Black)

 <a href="#top"> Go back to previous</a><br/></h2>
 
 <a name="product details4"></a><br/>	  
<img src="https://cdn.shopify.com/s/files/1/0941/7790/products/angle-in-mineral-aqua-throw-pillow-411757_800x.jpg?v=1611191141" alt="pillow"width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://assets.weimgs.com/weimgs/ab/images/wcm/products/202115/0263/reflected-angles-pillow-covers-c.jpg" alt="pillow3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<h2>JY Satin Stripes Reliance Microfiber Pillows in White Color Set of  
 
  <a href="#top"> Go back to previous</a><br/></h2>
 
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>

</pre><center></body></html>