<html>
<head>
<title> living room products </title>
<link rel="stylesheet" href="C:\Users\dhars\Desktop\WT Lab\Furnished Flow\styles.css" />
<script src="C:\Users\dhars\Desktop\WT Lab\Furnished Flow\Small Codes\store.js" async></script>
<style>
a:link {
  color: black;
  text-decoration: none;
}
a:visited {
  color: black;
  text-decoration: none;
}
a:active {
  color: gray;
  background-color: transparent;
  text-decoration: none;
}
</style>
</head>
<body>
<pre>
<a href="http://localhost/WT%20php/CAT%202/Main%20Page.php"> Go to Home Page</a>
<center>
<h1>Living Room Products</h1>
<a name="top"></a>
<h1><b> SOFA SET </b></h1>
<img  src="https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/sectional-sofa-1551367430.jpg?crop=1xw:1xh;center,top&resize=480:*" alt="sofa" width="300" height="300" border="1px"><br/>
<a href="#product details1"> click to view product details</a><br/>

<h1><b> COFFEE TABLE </b></h1>
<img  src="https://ii1.pepperfry.com/media/catalog/product/i/b/1100x1210/ibiza-side-table--set-of-3--in-gold--copper---antique-finish-by-strawberry-collective-ibiza-side-tab-aganqp.jpg" alt="coffee table" width="300" height="300" border="1px"><br/>
<a href="#product details2"> click to view product details</a><br/>

<h1><b> BOOK SHELF </b></h1>
<img  src="https://wakefit-co.s3.ap-south-1.amazonaws.com/img/bookshelves/plath/5-shelves/0.jpg" alt="book shelf" width="300" height="300" border="1px"><br/>
<a href="#product details3">click to view product details</a><br/>

<h1><b> BEAN BAG </b></h1>
<img  src="https://images-na.ssl-images-amazon.com/images/I/71vLjpZ3m2L._AC_SL1000_.jpg" alt="bean bag" width="300" height="300" border="1px"><br/>
<a href="#product details4"> click to view product details</a><br/>

 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 
 <a name="product details1"></a><br/>	  
<img src="https://media.wired.com/photos/5f6e518b472ed04367fece2c/master/w_400%2Cc_limit/Gear-Burrow-Couch-src-Burrow.jpg" alt="sofa2" width="400" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://img.castlery.co/products/images/150960/small/Issac-Left-Reversible-Sectional-Sofa-Ivory-Beige-Front.jpg?1615890308" alt="sofa3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://cdn.shopify.com/s/files/1/0462/1706/8706/products/TheSofaTwoSeater-Upholstered_Back_3Qtr_Post_1200x.png?v=1613599470" alt="sofa4" width="300" height="300" border="1px"> 
 <h2>Solimo Cartina Fabric 5 seater L shape sofa Set (Grey)   

  <a href="#top"> Go back to previous</a> <br/></h2>
 
 <a name="product details2"></a><br/>	  
<img src="https://res.cloudinary.com/optsolservices/image/upload/w_600,f_auto/v1604480145/wey/prd/I00001987_ifhexm.jpg" alt="coffee table2"width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://ii1.pepperfry.com/media/catalog/product/i/b/568x625/ibiza-side-table--set-of-3--in-gold--copper---antique-finish-by-strawberry-collective-ibiza-side-tab-2jkgxb.jpg" alt="coffee table3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://ii1.pepperfry.com/media/catalog/product/i/b/568x625/ibiza-side-table--set-of-3--in-gold--copper---antique-finish-by-strawberry-collective-ibiza-side-tab-nfogzz.jpg" alt="coffee table4" width="300" height="300" border="1px"> 
 <h2>DeckUp Dusun Coffee Table (Dark Wenge, Matte Finish) 

  <a href="#top"> Go back to previous</a><br/></h2>
 
 <a name="product details3"></a><br/>	  
<img src="https://wakefit-co.s3.ap-south-1.amazonaws.com/img/bookshelves/plath/5-shelves/1.jpg" alt="book shelf2"width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://wakefit-co.s3.ap-south-1.amazonaws.com/img/bookshelves/plath/5-shelves/trust-badges/2.jpg" alt="book shelf3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://wakefit-co.s3.ap-south-1.amazonaws.com/img/bookshelves/plath/5-shelves/trust-badges/3.jpg" alt="book shelf4" width="300" height="300" border="1px"> 
 <h2>Flexible Bookshelf Display Shelf - Free Style 

 <a href="#top"> Go back to previous</a><br/></h2>
 
 <a name="product details4"></a><br/>	  
<img src="https://images-na.ssl-images-amazon.com/images/I/512MJB9kMYL._AC_SL1001_.jpg" alt="chair2"width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://images-na.ssl-images-amazon.com/images/I/51yRQVUMFIL._AC_SL1001_.jpg" alt="chair3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://images-na.ssl-images-amazon.com/images/I/6107-bv%2BSjL._AC_SL1200_.jpg" alt="chair4" width="300" height="300" border="1px"> 
<h2>Nest Bedding Bean Bag Chair 

      <a href="#top"> Go back to previous</a><br/></h2>
 
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>

</pre><center></body></html>