
<html>
<head>
<title> About Us </title>
<link rel="stylesheet" href="styles.css" />
<style type="text/css">
	body{
	background-image: url("C:\Users\dhars\Desktop\WT Lab\Furnished Flow\pics\abtus.jpg");
	background-repeat:no-repeat;
	background-attachment:fixed;
	background-size:100%100%;
	opacity:0.5;
	}
</style>
</head>
<body>
<a style="text-decoration:none" href="http://localhost/WT%20php/CAT%202/Main%20Page.php"> <b style="color:black;">Go to Home Page</b></a>
<center><h1 font face = "Times New Roman" font color = "black"> FURNISHED FLOW - ABOUT US </h1>
<center><h2 font face = "Times New Roman" font color = "black"> Coimbatore , Tamilnadu. </h2>
<center><h2 font face = "Times New Roman" font color = "black"> Buy home decorations and accessories at Furnished Flow </h2>
<hr align="center" size="2" width="100%" color="black">
<pre>
<h3>
<b>Revamp Your House with Lavish Home, Decor:</b>
A home is what you make it! So turn the four walls of your house into a home with aesthetic Decor, making it a place for memories to be
 born. In India, home Decor exists since the royal era. Palaces or mud houses, everyone loved decorating their homes back then. Home Decor
 plays a vital role in setting the ambiance and environment of your house. A single change in the color or lighting can impact its entire 
 feel.Before going for a home makeover, it is important to understand the theme you want, the Decor objects that will fit in, and the 
 placement of these objects to avoid stuffing. If classic is your taste, then you can go for a traditional or vintage Decor theme. You 
 wish to follow the trends, then a modern or contemporary theme is the ideal pick. Remember, your home Decor expresses your personality.
 Therefore, follow your heart and go for a theme that speaks aloud your style.

<b>Different Home Decor Items Available Online</b>
You are provided with a galore of Decor options that you can choose from at Furnished Flow. Be it setting up your kitchen,
 bedroom, living room, kids room, or bathroom; you can select products that will blend along with your home. Following 
 are some Decor ideas that you can give a thought to:

<b>Garden Decor:</b>
If your house features an open space or balcony, you can own a mini garden. You can decorate it with the alluring garden
decoration items such as garden figurines, pots and planters, artificial flowers, artificial grass, bird houses, 
decorative pebbles, and outdoor lighting.

<b>Kitchen Decor:</b>
Browse through a lavish collection of homeware to set up your kitchen. You can choose from products such as dinner table sets, 
utensil holders, kitchen baskets, everyday glasses, pitchers and decanters, mason jars, coasters, salt and pepper shakers, 
table linen, and so on. Decorate your kitchen with subtle lighting and simple wall paintings to give it a chic look.

<b>Bedroom Decor:</b>
Bedroom decoration can be a tedious task because if not set right, it can mess up with your sleeping and dressing. 
Furnished Flow has a wide range of bedroom furniture and bedding. You can choose from different bed types, such as upholstered, 
sofa cum bed, trundle, loft, bunk, novelty, and others. There are even cribs available for kid's room. Bedding options include 
mattresses, duvets, comforters, mattress protectors, duvet covers, pillows, and bed wedges. Lighting plays an important role; 
the placement of bedside lamps should be proper. You can even install wall sconces or hanging lights to give it a luxe touch. 
Choose from bedside tables, study tables, and bean bags to perfectly match your theme.


<b>Living Room Decor:</b>
You can style up your living room with plush decor such as recamiers, lounge chairs, end tables, console tables, 
coffee tables, cabinets, shoe racks, show pieces, planters, indoor fountain, wall art, photo frames, and what not! 
Add a chandelier, hanging lantern, or any suitable lighting, and you're ready to go.
</h3>
</pre>
<p><b>Connect to us:</b> 
 
 <center> <a href="https://www.facebook.com/pages/category/Local-Service/Furnished-Flow-109316150745620/"> <img src = "C:\Users\dhars\Desktop\WT Lab\Furnished Flow\pics\fb.jpg" alt = "facebook" style="width:80px;height:70px;" /></a>
 <a href="https://www.instagram.com/furnishedflow/?hl=en">  <img src = "C:\Users\dhars\Desktop\WT Lab\Furnished Flow\pics\ig.jpg" alt = "instagram" style="width:75px;height:75px;"/>  </a> </center>  
</p>
</body>
</html>