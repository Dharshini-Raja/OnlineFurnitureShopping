<html>
<head>
<title>Beds</title>
</head>
<body>
<img src="https://www.thespruce.com/thmb/aX-KHJy0u29cy9PrND5GoK_74dI=/3733x2800/smart/filters:no_upscale()/tips-for-buying-a-great-sofa-1391218-hero-49e5709562ef449b8b77492558e37201.jpg" alt="Couch" width="580" height="510">
</body>
</html>