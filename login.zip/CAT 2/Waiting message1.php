<html>
<head>
<title>Product Picture</title>
</head>
<body>
<img src="https://wallpaperaccess.com/full/2076140.jpg" alt="LivingRoom" usemap="#livroommap" height="510px" width="640px">
<br><br><br>
</body>
</html>