<html>
<head>
<title>Side Tables</title>
</head>
<body style="background-color:#BDDACF;">
<pre style="font-size:27px;">
<h1><b><u>Side Tables</u></b></h1>
The chairs are designed sophisticatedly
with a side table on the side.
It costs from Rs.8000 to Rs.15000.
It can hold upto 100kg of weight.
8+ years warranty available.
Free installation available 
for some products.
</pre>
</body>
</html>