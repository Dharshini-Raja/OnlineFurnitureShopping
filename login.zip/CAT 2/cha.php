<html>
<head>
<title>Designer Chairs</title>
</head>
<body>
<img src="https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1580746458-resize.jpg" alt="Designer Chairs" width="580" height="510">
</body>
</html>