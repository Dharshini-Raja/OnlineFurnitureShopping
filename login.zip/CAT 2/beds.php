<html>
<head>
<title>Beds</title>
</head>
<body style="background-color:#BDDACF;">
<pre style="font-size:27px;">
<h1><b><u>Beds</u></b></h1>
Beds of all sizes are available.
Price range varies according to
the size of the bed. Usually from
Rs.12000 to Rs.30000. Beds can  
support the weight of 6 average sized persons. 
10+ years warranty available. 
Standard Installation fee: Rs.999.
</pre>
</body>
</html>