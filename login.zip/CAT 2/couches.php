<html>
<head>
<title>Couches</title>
</head>
<body style="background-color:#BDDACF;">
<pre style="font-size:27px;">
<h1><b><u>Couches</u></b></h1>
Couches start from the price of
Rs.8000 to Rs.15000.
It can hold upto 500kg of weight. 
15+ years warranty available.
Free installation.
</pre>
</body>
</html>