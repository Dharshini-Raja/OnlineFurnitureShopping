<html>
<head>
<title> home decor </title>
<link rel="stylesheet" href="C:\Users\dhars\Desktop\WT Lab\Furnished Flow\styles.css" />
<script src="C:\Users\dhars\Desktop\WT Lab\Furnished Flow\Small Codes\store.js" async></script>
<style>
a:link {
  color: black;
  text-decoration: none;
}
a:visited {
  color: black;
  text-decoration: none;
}
a:active {
  color: gray;
  background-color: transparent;
  text-decoration: none;
}
</style>
</head>
<body>
<pre>
<a href="http://localhost/WT%20php/CAT%202/Main%20Page.php"> Go to Home Page</a>
<center>
<h1>Decor</h1>
<a name="top"></a>
<h1><b> LAMP </b></h1>
<img  src="https://i.pinimg.com/originals/bd/fa/6e/bdfa6ea990ac4ccb8b70df1ad733bddb.jpg" alt="lamp" width="300" height="300" border="1px"><br/>
<a href="#product details1"> click to view product details</a><br/>

<h1><b> CLOCK </b></h1>
<img  src="https://images-na.ssl-images-amazon.com/images/I/71GGSVHTnqL._SY355_.jpg" alt="clock" width="300" height="300" border="1px"><br/>
<a href="#product details2"> click to view product details</a><br/>

<h1><b> KEY HOLDERS </b></h1>
<img  src="https://i.pinimg.com/originals/07/87/76/078776445e8c24eb2f33e65d1765e763.jpg" alt="key" width="300" height="300" border="1px"><br/>
<a href="#product details3">click to view product details</a><br/>

<h1><b> SCREEN AND DIVIDER </b></h1>
<img  src="https://homebnc.com/homeimg/2019/10/22-best-room-divider-ideas-designs-homebnc.jpg" alt="divider" width="400" height="300" border="1px"><br/>
<a href="#product details4"> click to view product details</a><br/>

 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 
 <a name="product details1"></a><br/>	  
<img src="https://5.imimg.com/data5/SELLER/Default/2020/9/DB/QA/EH/80515538/product-image-angle-brown-wooden-floor-lamp-8-500x500.jpg" alt="lamp2" width="250" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://5.imimg.com/data5/SELLER/Default/2020/9/KZ/LR/WE/80515538/product-image-angle-brown-wooden-floor-lamp-1-500x500.jpg" alt="lamp3" width="250" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://5.imimg.com/data5/SELLER/Default/2020/9/BV/BD/BD/80515538/product-image-angle-brown-wooden-floor-lamp-5-500x500.jpg" alt="lamp4" width="250" height="300" border="1px"> 
 <h2> SANDED EDGE - SMARTLY PRICED Metal Floor Lamp, Beige  

 <a href="#top"> Go back to previous</a> <br/></h2>
 
 <a name="product details2"></a><br/>	  
<img src="https://images-na.ssl-images-amazon.com/images/I/71q2iqc-MfL._SS400_.jpg" alt="clock2"width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://images-na.ssl-images-amazon.com/images/I/81bQfLJN7ZL._SS400_.jpg" alt="clock3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://images-na.ssl-images-amazon.com/images/I/71fPJgQ7%2BKL._SS400_.jpg" alt="clock4" width="300" height="300" border="1px"> 
 <h2> E Deals Abstract Printed Wall Clock 10 Inches Round Shaped Designer Wall Clock 
 
 <a href="#top"> Go back to previous</a><br/></h2>
 
 <a name="product details3"></a><br/>	  
<img src="https://i.pinimg.com/736x/7a/56/4f/7a564f223430cb4f4079e213cfa24411.jpg" alt="key2"width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://i.etsystatic.com/5815358/r/il/dca752/1555783399/il_570xN.1555783399_rz10.jpg" alt="key3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://i.pinimg.com/originals/7b/00/c5/7b00c5f848ace4afa6645b7a9319f58f.jpg" alt="key4" width="300" height="300" border="1px"> 
 <h2>Webelkart Premium "Keys" Wooden Key Holder

 <a href="#top"> Go back to previous</a><br/></h2>
 
 <a name="product details4"></a><br/>	  
<img src="https://m.media-amazon.com/images/I/61yeIUmlvYL._AC_SS450_.jpg" alt="divider2"width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://images.thdstatic.com/productImages/da88842d-e94a-4b57-b519-b20349705ac0/svn/black-oriental-furniture-room-dividers-ssfiber-6p-blk-64_1000.jpg" alt="divider3" width="300" height="300" border="1px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<h2> Woodykart Mango Wood Wooden Partition Leaves Design/Room Divider

            <a href="#top"> Go back to previous</a><br/></h2>
 
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>

</pre><center>
<?php

?>
</body></html>