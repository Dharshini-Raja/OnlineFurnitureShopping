<html>
<head>
<title>Glass Top Coffee Tables</title>
</head>
<body style="background-color:#BDDACF;">
<pre style="font-size:27px;">
<h1><b><u>Glass Top Coffee Tables</u></b></h1>
The glass top coffee tables are available 
in price range from Rs.5000 to Rs.12000.
It can hold upto 80kg of weight.
5+ years warranty available. 
Free installation.
</pre>
</body>
</html>