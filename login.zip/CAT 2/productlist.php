<html>
<head>
<title>Products List</title>
<style>
a:link {
  color: black;
  background-color: transparent;
  text-decoration: none;
}
a:visited {
  color: #1F8B93;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: #D57B7E;
  background-color: transparent;
  text-decoration: underline;
}
a:active {
  color: #7BD5B1;
  background-color: transparent;
  text-decoration: none;
}
</style>
</head>
<body>
<h1><center>List of Interior Products</h1>
<pre style="font-size:22px;">
<ul>
<li><b><a href= "coffee.php" target="f3" >Coffee Table</a></b></li>   <a href="coff.php" target="f4" >(display)</a> 
<li><b><a href="chair.php" target="f3" >Designer Chair</a></b></li>   <a href="cha.php" target="f4" >(display)</a> 
<li><b><a href="desk.php" target="f3" >Work Desk</a></b></li>   <a href="work.php" target="f4" >(display)</a> 
<li><b><a href="sidetables.php" target="f3" >Side Table</a></b></li>   <a href="side.php" target="f4">(display)</a> 
<li><b><a href="glasstopcoffeetable.php" target="f3" >Glass Top Coffee Table</a></b></li>   <a href="glasscoff.php" target="f4" >(display)</a> 
<li><b><a href="beds.php" target="f3" >Beds</a></b></li>   <a href="bedss.php" target="f4"  >(display)</a> 
<li><b><a href="couches.php" target="f3" >Couches</a></b></li>   <a href="cou.php" target="f4"  >(display)</a> 

</ul>
</pre>
</body>
</html>