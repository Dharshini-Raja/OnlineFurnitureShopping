<html>
<head>
<title>Furnished Flow | Home</title>
</head>
<frameset rows="20,5,75" >
	<frame src="http://localhost/WT%20php/CAT%202/title.php" name="Furnished Flow">
	<frame src="http://localhost/WT%20php/CAT%202/menubar.php" name="f1">
	<frameset cols="20,55,50">
		<frame src="http://localhost/WT%20php/CAT%202/productlist.php" name="f2">
		<frame src="http://localhost/WT%20php/CAT%202/Waiting%20message1.php" name="f3">
		<frame src="http://localhost/WT%20php/CAT%202/Waiting%20Message2.php" name="f4">	
	</frameset>
</frameset>
</html>