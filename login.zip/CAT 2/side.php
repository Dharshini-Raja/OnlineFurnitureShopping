<html>
<head>
<title>Side Tables</title>
</head>
<body>
<img src="https://ii1.pepperfry.com/media/catalog/product/y/u/1100x1210/yuko-bed-side-table-in-columbia-walnut-finish-by-mintwud-yuko-bed-side-table-in-columbia-walnut-fini-fxyxod.jpg" alt="SideTable" width="580" height="510">
</body>
</html>