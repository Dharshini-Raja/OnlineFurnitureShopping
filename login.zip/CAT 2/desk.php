<html>
<head>
<title>Work Desks</title>
</head>
<body style="background-color:#BDDACF;">
<pre style="font-size:27px;">
<h1><b><u>Work Desks</u></b></h1>
Minimalistic work desk is done
in work desks which are in the price 
range Rs.4000-Rs.10000 which are ideal 
to hold upto 750kg of weight
15+ years warranty available.
Standard Installation fee: Rs.450.
</pre>
</body>
</html>