<html>
<head>
<title> Waiting Message </title>
</head>
<body>
<center>
<center><img src="https://wallpaperaccess.com/full/2076139.jpg" alt="LivingRoom" usemap="#bedroommap" height="510px" width="580px">
</body>
</html>