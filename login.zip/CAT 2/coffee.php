<html>
<head>
<title>Coffee Tables</title>
</head>
<body style="background-color:#BDDACF;">
<pre style="font-size:27px;">
<h1><b><u>Coffee Tables</u></b></h1>
Coffee tables starts with the price of Rs.2500.
It is durable and can hold upto
80kg of weight.
3+ years warranty available. 
Free installation.
</pre>
</body>
</html>