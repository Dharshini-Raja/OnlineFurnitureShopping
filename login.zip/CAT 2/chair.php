<html>
<head>
<title>Designer Chairs</title>
</head>
<body style="background-color:#BDDACF;">
<pre style="font-size:27px;">
<h1><b><u>Designer Chairs</u></b></h1>
Modern designer chairs are available
in the range of Rs.1500 to Rs.4600.
It is strong and longlasting.
It holds upto 200kg of weight.
8+ years warranty available.
Installation fee is mandatory for
certain products.
</pre>
</body>
</html>