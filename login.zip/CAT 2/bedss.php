<html>
<head>
<title>Beds</title>
</head>
<body>
<img src="https://www.thesleepjudge.com/wp-content/uploads/2017/06/Darby-Home-Co.-Thousand-Oaks-Storage-Platform-Bed.jpg" alt="Beds" width="580" height="510">
</body>
</html>