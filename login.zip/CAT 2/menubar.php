<html>
<head>
<title>Menu Bar</title>
<style>
a:link { 
  color: black;
  background-color: transparent;
  text-decoration: none;
}
a:visited {
  color: black;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: #D57B7E;
  background-color: transparent;
  text-decoration: underline;
}
a:active {
  color: #7BD5B1;
  background-color: transparent;
  text-decoration: none;
}
input[type=submit] {
  border: none;
  color: black;
  text-decoration: none;
  cursor: pointer;
}
input[type=submit]:hover {
  background-color: #839192;
  color: black;
}

</style>
</head>
<body>
<form name="form1" method="POST" target="_top" action="http://localhost/WT%20php/CAT%202/search.php">
<a href="http://localhost/WT%20php/CAT%202/living.php" target="_top"><b>Living Room Products</b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/WT%20php/CAT%202/bedroom.php" target="_top"><b>Bedroom Products</b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/WT%20php/CAT%202/decor.php" target="_top"><b>Decor</b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

		<input type="text" placeholder="Search" name="search" aria-label="Search" size="70" required>
		<input type="submit" value="search" name="submit"></input>
		
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/WT%20php/CAT%202/php-pdf-master/" target="_top"><b>Your orders</b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/WT%20php/Login/" target="_top"><b>Shop Now!!</b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/WT%20php/CAT%202/Main%20Page.php" target="_top"><b>Home</b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://localhost/WT%20php/CAT%202/about%20us%20page.php" target="_top"><b>About Us</b></a>
	</form>

</body>

</html>
