<html>
<head>
<title>Title</title>
</head>
<body>
<center>
<img src="https://i.pinimg.com/originals/44/62/d6/4462d63a94c90452ec5023d538ba6871.jpg"  height="135px" width="200px" alt="logo" align="left">
<h1 font color = "blue">FURNISHED FLOW</h1>
<h3>852-A, Mark Avenue Street, Coimbatore-25.</h3>
</body>
</html>